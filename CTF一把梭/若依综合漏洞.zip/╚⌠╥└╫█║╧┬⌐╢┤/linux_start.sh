#!/bin/bash
current_dir=$(dirname "$0")
echo "当前脚本所在目录的路径是：$current_dir"
cd $current_dir
../jdk1_8_0_291/bin/java -jar ruoyiVuln.jar
